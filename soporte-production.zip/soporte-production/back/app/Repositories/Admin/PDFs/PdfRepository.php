<?php

namespace App\Repositories\Admin\PDFs;

class PdfRepository
{
    public function __construct()
    {
        //
    }
}
