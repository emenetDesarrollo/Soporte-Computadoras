export const api = 'https://scosm-back.m-net.mx/public/api';
//export const api = 'http://localhost:8000/api';
export const api_bot = 'http://localhost:3000/api';